from setuptools import setup
setup(
    name="Paquete de cálculos",
    version="1.0",
    description="Cálculos básicos matemáticos",
    author="Jocelyn",
    url="jogubaez@hotmail.com",
    packages=["calculos"]
)